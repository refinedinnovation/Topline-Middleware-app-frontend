"use client";
import UploadAndConvertFile from '@/components/dashboard/convert/uploadAndConvertFile';
import React from 'react';

const FileUpload = () => {


    return (
        <UploadAndConvertFile />
    );
};

export default FileUpload;
