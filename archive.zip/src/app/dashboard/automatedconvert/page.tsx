"use client";
import AutomatedConvert from '@/components/dashboard/automatedconvertt/automatedConvert';
import React from 'react';

const FileUploadAuto = () => {


    return (
        <AutomatedConvert />
    );
};

export default FileUploadAuto;
