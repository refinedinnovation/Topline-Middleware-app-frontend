"use client";
import Logs from '@/components/dashboard/logs/logs';
import React from 'react';

const logsauto = () => {


    return (
        <Logs />
    );
};

export default logsauto;
