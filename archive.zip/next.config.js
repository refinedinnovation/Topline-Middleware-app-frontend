/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  images: {
    unoptimized: true,
  },
  async rewrites() {
    return [
      {
        source: "/api/v1/:path*", // Any request starting with /api will be rewritten
        destination: "http://178.79.133.148:4040/api/v1/:path*", // Target API URL
      },
    ];
  },
};

module.exports = nextConfig;

